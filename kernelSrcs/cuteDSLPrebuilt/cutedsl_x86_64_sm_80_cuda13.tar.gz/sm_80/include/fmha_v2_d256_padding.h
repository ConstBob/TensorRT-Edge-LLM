
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} fmha_v2_d256_padding_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_fmha_v2_d256_padding_cuda_init(void **);
void _mlir_fmha_v2_d256_padding_cuda_load_to_device(void **);
static inline void fmha_v2_d256_padding_Kernel_Module_Load(fmha_v2_d256_padding_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_fmha_v2_d256_padding_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_fmha_v2_d256_padding_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void fmha_v2_d256_padding_Kernel_Module_Unload(fmha_v2_d256_padding_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} fmha_v2_d256_padding_Tensor_mQ_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} fmha_v2_d256_padding_Tensor_mK_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} fmha_v2_d256_padding_Tensor_mV_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} fmha_v2_d256_padding_Tensor_mO_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} fmha_v2_d256_padding_Tensor_mCuSeqLenQ_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} fmha_v2_d256_padding_Tensor_mCuSeqLenK_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_fmha_v2_d256_padding__mlir_ciface_cutlass___call_____main__FMHAV2Ampere_object_at__Tensorgmemo256i64div256i64div2562561_Tensorgmemo256i64div256i64div2562561_Tensorgmemo256i64div256i64div2562561_Tensorgmemo256i64div(void **args, int32_t num_args);

static inline int32_t cute_dsl_fmha_v2_d256_padding_wrapper(fmha_v2_d256_padding_Kernel_Module_t *module, fmha_v2_d256_padding_Tensor_mQ_t *mQ, fmha_v2_d256_padding_Tensor_mK_t *mK, fmha_v2_d256_padding_Tensor_mV_t *mV, fmha_v2_d256_padding_Tensor_mO_t *mO, fmha_v2_d256_padding_Tensor_mCuSeqLenQ_t *mCuSeqLenQ, fmha_v2_d256_padding_Tensor_mCuSeqLenK_t *mCuSeqLenK, float softmax_scale, int32_t num_kv_heads, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[10] = {
        mQ, mK, mV, mO, mCuSeqLenQ, mCuSeqLenK, &softmax_scale, &num_kv_heads, &stream,
        &ret
    };
    _mlir_fmha_v2_d256_padding__mlir_ciface_cutlass___call_____main__FMHAV2Ampere_object_at__Tensorgmemo256i64div256i64div2562561_Tensorgmemo256i64div256i64div2562561_Tensorgmemo256i64div256i64div2562561_Tensorgmemo256i64div(args, 10);
    return ret;
}
