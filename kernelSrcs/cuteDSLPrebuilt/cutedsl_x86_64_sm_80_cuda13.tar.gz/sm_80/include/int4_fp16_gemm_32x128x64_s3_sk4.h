
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} int4_fp16_gemm_32x128x64_s3_sk4_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_int4_fp16_gemm_32x128x64_s3_sk4_cuda_init(void **);
void _mlir_int4_fp16_gemm_32x128x64_s3_sk4_cuda_load_to_device(void **);
static inline void int4_fp16_gemm_32x128x64_s3_sk4_Kernel_Module_Load(int4_fp16_gemm_32x128x64_s3_sk4_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_int4_fp16_gemm_32x128x64_s3_sk4_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_int4_fp16_gemm_32x128x64_s3_sk4_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void int4_fp16_gemm_32x128x64_s3_sk4_Kernel_Module_Unload(int4_fp16_gemm_32x128x64_s3_sk4_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mA_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mQW_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mScales_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mC_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mWorkspace_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mLocks_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_int4_fp16_gemm_32x128x64_s3_sk4__mlir_ciface_cutlass___call_____main__Int4Fp16GemmAmpere_object_at__Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tenso(void **args, int32_t num_args);

static inline int32_t cute_dsl_int4_fp16_gemm_32x128x64_s3_sk4_wrapper(int4_fp16_gemm_32x128x64_s3_sk4_Kernel_Module_t *module, int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mA_t *mA, int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mQW_t *mQW, int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mScales_t *mScales, int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mC_t *mC, int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mWorkspace_t *mWorkspace, int4_fp16_gemm_32x128x64_s3_sk4_Tensor_mLocks_t *mLocks, int32_t swizzle, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[9] = {
        mA, mQW, mScales, mC, mWorkspace, mLocks, &swizzle, &stream,
        &ret
    };
    _mlir_int4_fp16_gemm_32x128x64_s3_sk4__mlir_ciface_cutlass___call_____main__Int4Fp16GemmAmpere_object_at__Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tenso(args, 9);
    return ret;
}
